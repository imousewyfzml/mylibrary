class Messagelog:
    def __init__(self, enable = 1, prefix=''):
        self.enable = enable
        self.prefix = prefix

    def log(self, message):
        if self.enable:
            print(self.prefix + message)