import pygame
from array import array
from pygame.rect import Rect


class Gamegrid:
    def __init__(self, x, y, initializationstring):
        self.x = x;
        self.y = y;
        self.grid = array('c');
        if (len(initializationstring) != x*y):
            raise AttributeError('Gamegrid mismatches size');
        self.grid.fromstring(initializationstring);
        self.wallchar = 'x';

    def fullrender(self, screen, x_offset, y_offset, unitsize):
        #screen.fill((255,255,255,255));

        wallelement = Rect(x_offset, y_offset, unitsize, unitsize);
        for i in range(self.x):
            for j in range(self.y):
                # print ("i,j = " + str(i) + ", " + str(j));
                wallelement.x = x_offset+i*unitsize;
                wallelement.y = y_offset+j*unitsize;
                if self.isWall(i,j):
                    screen.fill((0,0,0), wallelement);
        pygame.display.update();

    def isWall(self, piece_x, piece_y):
        return self.wallchar == self.grid[piece_x+piece_y*self.x];