import food
import snake
import unittest, pdb

class TestFoodmanager(unittest.TestCase):


    def testEating(self):
        snakefood = food(1,0) # place a piece of food on (x,y) = (1,0)
        mysnake = snake.ProtoSnake((255,172,255), 0, 0, (255, 255,255), snake.ProtoSnake.right)


if __name__ == '__main__':
    #unittest.main();
    suite = unittest.TestLoader().loadTestsFromTestCase(TestFoodmanager)
    unittest.TextTestRunner(verbosity=2).run(suite)