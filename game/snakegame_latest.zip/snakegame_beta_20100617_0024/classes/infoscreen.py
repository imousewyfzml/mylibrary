import pygame
import tools.mediahelper


class Infoscreen:
    margin = 5

    def __init__(self, width, height, fontcolor=None, backcolor = None):
        self.width = width
        self.height = height
        if None == backcolor:
            backcolor = (255, 255, 255)
        if None == fontcolor:
            fontcolor = (0,0,0)
        self.fontcolor = fontcolor
        self.backcolor = backcolor
        self.time = 175 # time in seconds
        self.level = 1
        self.score = 1280
        self.helptext = None

    def render(self, screen, x=0, y=0):
        screen.fill(self.backcolor, pygame.rect.Rect(x, y, self.width, self.height))
        minutes = self.time / 60
        seconds = self.time % 60
        timestring = 'remaining time: ' + str(minutes) + ':' + str(seconds)
        tools.mediahelper.showText(screen, timestring, 20, x+self.width/2, y + Infoscreen.margin, self.fontcolor, self.backcolor, 'top', 'center' )
        scorestring = 'score: ' + str(self.score)
        tools.mediahelper.showText(screen, scorestring, 20, x+self.width-Infoscreen.margin, y + Infoscreen.margin, self.fontcolor, self.backcolor, 'top', 'right' )
        levelstring = 'level: ' + str(self.level)
        tools.mediahelper.showText(screen, levelstring, 20, x+Infoscreen.margin, y + Infoscreen.margin, self.fontcolor, self.backcolor, 'top', 'left' )
        if (None!=self.helptext):
            tools.mediahelper.showText(screen, self.helptext, 20, x+Infoscreen.margin, y + self.height - Infoscreen.margin, self.fontcolor, self.backcolor, 'bottom', 'left' )


if __name__ == '__main__':
    import time, sys, traceback
    width = 640;
    height = 480;
    pygame.init();
    pygame.font.init();
    screen = pygame.display.set_mode((width, height));
    try:
        info = Infoscreen(640, 50)
        info.render(screen)
        pygame.display.update()
        time.sleep(5)
    except Exception, e:
        tb = sys.exc_info()[2]
        traceback.print_exception(e.__class__, e, tb)
        raw_input('\nenter to exit\n');
    pygame.quit();