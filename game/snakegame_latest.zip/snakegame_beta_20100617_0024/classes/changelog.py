print("""changelog:
alpha2 (27.5.2010)
    real unit tests
    removed complexity (in purest sense of the word):
    absolute movements""")