import pygame, sys, traceback
import classes.game

if __name__ == '__main__':
    width = classes.game.Game.width;
    height = classes.game.Game.height+classes.game.Game.infoheight;
    pygame.init();
    pygame.font.init();
    screen = pygame.display.set_mode((width, height));
    try:
        game = classes.game.Game(screen)
        game.mainloop();
    except Exception, e:
        tb = sys.exc_info()[2]
        traceback.print_exception(e.__class__, e, tb)
        raw_input('\nenter to exit\n');
    pygame.quit();

