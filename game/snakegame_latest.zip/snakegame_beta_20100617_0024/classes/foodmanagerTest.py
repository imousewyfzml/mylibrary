import foodmanager
import pygame
import unittest, pdb


class TestFoodmanager(unittest.TestCase):


    def testGetFoodRect(self):
        backcol = (255,255,255)
        s = pygame.Surface((800,600))
        food = foodmanager.Foodmanager(s, 40, backcol, (255,0,0))
        s.fill(backcol)
        food.placeFood(30, 40)
        r = food.getFoodRect()
        self.assertEqual(r.width, 40)
        self.assertEqual(r.height, 40)
        self.assertEqual(r.x, 30)
        self.assertEqual(r.y, 40)


if __name__ == '__main__':
    #unittest.main();
    suite = unittest.TestLoader().loadTestsFromTestCase(TestFoodmanager)
    unittest.TextTestRunner(verbosity=2).run(suite)