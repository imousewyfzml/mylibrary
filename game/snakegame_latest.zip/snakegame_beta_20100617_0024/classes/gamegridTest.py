import unittest;
import sys, traceback;
from time import sleep;

import gamegrid;


class TestGamegridCreation(unittest.TestCase):

    def testsmallpositive(self):
        try:
            gg = gamegrid.Gamegrid( 5, 3, 'xxxxxx   xxxxxx');
        except AttributeError as e:
            self.fail('positive gamegridcheck failed');


    def testsmallnegative(self):
        self.failUnlessRaises(AttributeError, gamegrid.Gamegrid, 5, 3, 'jkxxxxxx   xxxxxx');


    def testView(self):
        # graphical test
        import pygame;
        # basic rendering
        width = 200;
        height = 200;
        pygame.init();

        try:
            screen = pygame.display.set_mode((width, height));
            gg = gamegrid.Gamegrid( 10, 8, 'xxxxxxxxxx'
                                      + 'x        x'
                                      + 'x        x'
                                      + 'x        x'
                                      + 'x        x'
                                      + 'x        x'
                                      + 'x        x'
                                      + 'xxxxxxxxxx');

            max_width = screen.get_bounding_rect().width;
            max_height = screen.get_bounding_rect().height;
            gg.fullrender(screen, 10, 10, 10);
        except Exception, e:
            tb = sys.exc_info()[2]
            traceback.print_exception(e.__class__, e, tb)

        sleep(3);
        pygame.quit();


if __name__ == '__main__':
    #unittest.main();
    suite = unittest.TestLoader().loadTestsFromTestCase(TestGamegridCreation)
    unittest.TextTestRunner(verbosity=2).run(suite)
    raw_input('enter\n');
