import os, pygame

def loadImage(file_name, colorkey=False, image_directory='media'):
    'Loads an image, file_name, from image_directory, for use in pygame'
    file = os.path.join(image_directory, file_name)
    try:
        _image = pygame.image.load(file)
    except Exception, e:
        print('load error, current dir:')
        print os.getcwd()
        raise e
    if colorkey:
        if colorkey == -1:
        # If the color key is -1, set it to color of upper left corner
            colorkey = _image.get_at((0, 0))
        _image.set_colorkey(colorkey)
        _image = _image.convert()
    else: # If there is no colorkey, preserve the image's alpha per pixel.
        _image = _image.convert_alpha()
    return _image


def showText(screen, textvalue, size=30, x=None, y=None, color=None, backcol=None, verticalAnchor=None, horizontalAnchor=None):
    ''' @param verticalAnchor choose from {center, top, bottom}
        @param horizontalAnchor choose from {center, left, right}'''
    if None == x:
        x = screen.get_bounding_rect().width/2
    if None == y:
        y = screen.get_bounding_rect().height/2
    if None == color:
        color = (0,0,0)
    if None == backcol:
        backcol = (255,255,255)
    if None == verticalAnchor or ('top' != verticalAnchor and 'bottom' != verticalAnchor):
        verticalAnchor = 'center'
    if None == horizontalAnchor or ('left' !=horizontalAnchor and 'right' != horizontalAnchor):
        horizontalAnchor = 'center'

    font = pygame.font.Font(None, size)
    text = font.render(textvalue, 1, color)
    # evaluate anchors
    if 'center' == horizontalAnchor:
        if  'center' == verticalAnchor:
            textpos = text.get_rect(centerx = x, centery = y)
        if 'top' == verticalAnchor:
            textpos = text.get_rect(centerx = x, top=y)
        if 'bottom' == verticalAnchor:
            textpos = text.get_rect(centerx = x, bottom=y)
    if 'left' == horizontalAnchor:
        if  'center' == verticalAnchor:
            textpos = text.get_rect(left = x, centery = y)
        if 'top' == verticalAnchor:
            textpos = text.get_rect(left = x, top=y)
        if 'bottom' == verticalAnchor:
            textpos = text.get_rect(left = x, bottom=y)
    if 'right' == horizontalAnchor:
        if  'center' == verticalAnchor:
            textpos = text.get_rect(right = x, centery = y)
        if 'top' == verticalAnchor:
            textpos = text.get_rect(right = x, top=y)
        if 'bottom' == verticalAnchor:
            textpos = text.get_rect(right = x, bottom=y)

    screen.fill(backcol, textpos)
    screen.blit(text, textpos)


def showImage(screen, image, x=None, y=None):
    if None == x:
        x = 0
    if None == y:
        y = 0
    screen.blit(image, (x, y))