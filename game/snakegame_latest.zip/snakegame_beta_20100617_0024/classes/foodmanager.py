import pygame, random


class Foodmanager():


    def __init__(self, screen, foodsize=10,
                backgroundcolor=(255,255,255,255), foodcolor=(255,0,0),
                suggestedgrowsize=10):
        (self.max_x ,self.max_y) = screen.get_size()
        self.screen = screen
        self.foodsize = foodsize
        self.background = backgroundcolor
        self.foodcolor = foodcolor
        self.x = 0
        self.y = 0
        self.active = 0
        self.suggestedgrowsize = suggestedgrowsize


    def placeFood(self, x=None, y=None):
        # dont place food, if currently active
        if self.active:
            return
        counter = 0
        while counter < 100 and (None==x or None==y):
            counter +=1
            size = self.foodsize
            halfsize= self.foodsize / 2
            x = random.randint(1,self.max_x-size) - 1
            y = random.randint(1,self.max_y-size) - 1
            checkpoints = []
            checkpoints.append((x, y))
            checkpoints.append((x+halfsize, y))
            checkpoints.append((x+size, y))
            checkpoints.append((x, y+halfsize))
            checkpoints.append((x+halfsize, y+halfsize))
            checkpoints.append((x+size, y+halfsize))
            checkpoints.append((x, y+size))
            checkpoints.append((x+halfsize, y+size))
            checkpoints.append((x+size, y+size))
            for point in checkpoints:
                col = self.screen.get_at(point)
                if col != self.background:
                    x = None
                    y = None
                    break

        # it could happen that there was no proper place found
        if None == x or None == y:
            print('could not place food')
            return

        self.x = x
        self.y = y
        self.active = 1


    def renderFood(self):
        if not self.active:
            return
        food = self.getFoodRect()
        self.screen.fill(self.foodcolor, food)


    def placeAndRenderFood(self):
        self.placeFood()
        self.renderFood()


    def getFoodRect(self):
        return pygame.Rect(self.x, self.y, self.foodsize, self.foodsize)


    def clearfood(self):
        if self.active:
            food = self.getFoodRect()
            self.screen.fill(self.background, food)
        self.active = 0