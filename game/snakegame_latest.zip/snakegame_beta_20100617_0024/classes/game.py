import pygame, time, cmath, random, os

import tools.debuggingtools
import tools.mediahelper
import infoscreen
import level


class Game:
    width = 840
    height = 400
    infoheight = 50
    maxleveltime = 60 # Todo Arcade-mode without time-limit
    snakecolor = (255, 100, 0) # Todo preconfigured snake-colorchoice (perhaps together with speed = difficulty)
    speed = 3
    maxlevel = 4
    inbetweenBackground = (0,0,0)
    inbetweenForeground = (140,140,140)

    def __init__(self, screen):
        self.info = infoscreen.Infoscreen(Game.width, Game.infoheight)
        self.maxfps = 30
        self.clock = pygame.time.Clock()
        self.mainscreen = screen
        self.myscreen = pygame.Surface((Game.width, Game.height))
        self.gamerect = pygame.rect.Rect(0, Game.infoheight, Game.width, Game.height)
        self.tryagainsmiley = tools.mediahelper.loadImage('happyface.png')
        self.winsmiley = tools.mediahelper.loadImage('face-grin.png')
        self.initGame();


    def initGame(self):
        self.gamerunning = 1
        self.score = 0
        self.levelnumber = 1
        self.initLevel()
        pygame.display.set_caption(".. .: game running :. ..")
        self.currentlevel.initGame()
        self.updateScreen()



    def initLevel(self):
        if 1==self.levelnumber:
             self.currentlevel = level.SimpleLevel(self.myscreen, Game.snakecolor, Game.speed)
        if 2==self.levelnumber:
             self.currentlevel = level.SimpleLevel2(self.myscreen, Game.snakecolor, Game.speed)
        if 3==self.levelnumber:
             self.currentlevel = level.SimpleLevel3(self.myscreen, Game.snakecolor, Game.speed)
        # todo: add more levels

        if 4==self.levelnumber:
             self.currentlevel = level.DifficultAILabyLevel(self.myscreen, Game.snakecolor, Game.speed)

        self.timecount = 0; # give game a timereference
        self.leveltime = Game.maxleveltime
        self.lastcaptionupdate = 0
        self.info.time = self.leveltime
        self.info.level = self.levelnumber
        self.info.score = self.score
        self.info.helptext = self.currentlevel.getLevelInfo()
        self.infochange = 1



    def updateScreen(self):
        if self.infochange:
            self.info.render(self.mainscreen)
            self.infochange = 0
        self.mainscreen.blit(self.myscreen, self.gamerect)
        pygame.display.update()


    def updateTime(self):
        oldleveltime = self.leveltime
        self.leveltime = Game.maxleveltime - (self.timecount / 1000)
        if self.leveltime < 0:
            self.leveltime = 0
        if oldleveltime > self.leveltime:
            self.info.time = self.leveltime
            self.infochange = 1


    def getTimebonus(self):
        return 10*self.leveltime


    def mainloop(self):
        paused = 0
        while 1:
            key = None;
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return;
                if (event.type == pygame.KEYDOWN):
                    if event.key == pygame.K_q:
                        return;
                    if (0 == self.gamerunning and pygame.K_n == event.key):
                        self.initGame();
                    elif (pygame.K_p == event.key):
                        paused = not paused
                        if self.gamerunning and paused:
                            pygame.display.set_caption(".. .: game paused :. .. ");
                    else:
                        key = event.key;

            passedmillis=0

            if (self.gamerunning and not paused):
                # the level itsel is responsible for one gamecycle
                status = self.currentlevel.cycle(key)

                if ("loose" == status):
                    tools.mediahelper.showText(self.myscreen, 'Boing! Try Again!', 30, None, Game.height/2 - 100, (0,0,0), (170,238,187,255))
                elif ("running" == status) and (0 == self.leveltime): # winning with 0 seconds is allowed
                    tools.mediahelper.showText(self.myscreen, 'Time Up! Try Again!', 30, None, Game.height/2 - 100, (0,0,0), (170,238,187,255))
                    status = "loose"

                if ("loose" == status):
                    tools.mediahelper.showImage(self.myscreen, self.tryagainsmiley, 20, 10)

                if ("win" == status):
                    tools.mediahelper.showText(self.myscreen, 'level finished', 30, None, Game.height/2 - 100, (0,0,0), (170,238,187,255))
                    self.updateScreen()
                    time.sleep(2)

                    # show score in an animated way
                    self.myscreen.fill(Game.inbetweenBackground);
                    levelscore = self.currentlevel.getScore()
                    timebonus = self.getTimebonus()
                    totalscore = self.score + levelscore + timebonus
                    stringpairs = []
                    stringpairs.append(('last score:', str(self.score)))
                    stringpairs.append(('levelscore:', str(levelscore)))
                    stringpairs.append(('timebonus:', str(timebonus)))
                    stringpairs.append(('totalscore:', str(totalscore)))
                    verticaloffset = -150
                    for (scoretype, scorevalue) in stringpairs:
                        tools.mediahelper.showText(self.myscreen, scoretype,
                                    30, Game.width/2 - 100, Game.height/2 + verticaloffset,
                                    Game.inbetweenForeground,
                                    Game.inbetweenBackground, None, 'left' )
                        tools.mediahelper.showText(self.myscreen, scorevalue,
                                    30, Game.width/2 + 150, Game.height/2 + verticaloffset,
                                    Game.inbetweenForeground,
                                    Game.inbetweenBackground, None, 'right')
                        self.updateScreen()
                        time.sleep(1)
                        verticaloffset += 50
                    self.score = totalscore
                    self.updateScreen()
                    time.sleep(3)

                    # try to go to the next level
                    if self.levelnumber < Game.maxlevel:
                        status = "running"
                        self.levelnumber += 1
                        self.initLevel()
                        self.updateScreen()
                        self.myscreen.fill(Game.inbetweenBackground);
                        tools.mediahelper.showText(self.myscreen,
                                'prepare for the next level', 30, None,
                                Game.height/2 - 100,
                                Game.inbetweenForeground,
                                Game.inbetweenBackground)
                        self.updateScreen()
                        time.sleep(2)
                        self.currentlevel.initGame();
                        # trick to not get to many passed millis after level init:
                        self.clock.tick(self.maxfps);
                    else:
                        tools.mediahelper.showText(self.myscreen, 'congratulation you got through all levels!', 30, None, Game.height/2 - 100, (0,0,0), (170,238,187,255))
                        tools.mediahelper.showImage(self.myscreen, self.winsmiley, 20, 10)
                        self.updateScreen()
                        time.sleep(3)

                if ("running" != status):
                    self.gamerunning = 0;
                    tools.mediahelper.showText(self.myscreen, "new game: press n / quit: press q", 30, None, None, None, (170,238,187,255));

                self.updateTime()
                self.updateScreen()

            # good quick game arch, however difficult for multilevels
            # trick look at above: insert one tick in between
            passedmillis = self.clock.tick(self.maxfps);
            self.timecount += passedmillis

            # only set the fps caption in a distinct intervall
            if self.gamerunning and self.lastcaptionupdate + 1000 < self.timecount:
                self.lastcaptionupdate = self.timecount
                fps = int(1000.0/passedmillis)
                pygame.display.set_caption(".. .: game running :. .. " + str(fps) + ' fps');
