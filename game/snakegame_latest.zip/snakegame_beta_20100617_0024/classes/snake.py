import cmath, random, pygame, math
from pygame.rect import Rect

import tools.debuggingtools
from tools.vec import Vec
import foodmanager


""" A snake has a length and a thickness. One unit equals one pixel.
    It is defined by a vector of directions.
"""
class ProtoSnake:
    left = Vec(-1,0)
    right = Vec(1,0)
    up = Vec(0,-1)
    down = Vec(0,1)


    def __init__(self, col=(125,125,0), x=100, y=100, backgroundcol=(255,255,255),
                head=down, length=80, thickness=15, food=None):
        self.color = col
        self.abspos = Vec(x, y)
        self.backgroundcol = backgroundcol
        self.snakelength = length
        self.initiallength = length
        if 0 == thickness%2: # thickness should be an odd number
            thickness += 1
        self.thickness = thickness
        # this list of vectors defines the turningpoints and their relative
        # distances
        self.inversedirectionvectors = [(-1) * head,] # start with one pixel
        if None == food:
            food = foodmanager.Foodmanager()
        self.food = food


    def __repr__(self):
        # '<ProtoSnake col=(0,0,0) pos=(20.0, 60.0) l=23 t=3 (0,-23);>'
        repr_entries = []
        repr_entries.append('<ProtoSnake')
        repr_entries.append('col=' + str(self.color))
        repr_entries.append('backcol=' + str(self.backgroundcol))
        repr_entries.append('pos=' + repr(self.abspos))
        repr_entries.append('l=' + str(self.snakelength))
        repr_entries.append('t=' + str(self.thickness))
        for vec in self.inversedirectionvectors:
            repr_entries.append(repr(vec)+';')
        return ' '.join(repr_entries) + '>'


    def reset(self, head):
        self.inversedirectionvectors = [(-1) * head,] # start with one pixel
        self.snakelength = self.initiallength


    def getsize(self):
        return self.snakelength


    def getTail(self):
        offset = self.abspos
        for direction in self.inversedirectionvectors:
            nextoffset = offset + direction
            offset = nextoffset
        return nextoffset


    def grow(self, size = 1):
        self.snakelength += size


    def fullrender(self, screen):
        offset = self.getScreenPos(screen)
        for direction in self.inversedirectionvectors:
            nextoffset = offset + direction
            pygame.draw.line(screen, self.color, offset.get(), nextoffset.get(), self.thickness)
            offset = nextoffset


    def drawWrappedLine(self, color, screen, offset, direction):
        # draw incomplete lines again from the end
        (targetx, targety) = (offset+direction).get()
        pygame.draw.line(screen, color, offset.get(), (targetx, targety), self.thickness)
        if (0>targetx or screen.get_width() >= targetx or 0>targety or screen.get_height() >= targety):
            clippedvec = self.getScreenPos(screen, offset+direction)
            pygame.draw.line(screen, color, clippedvec.get(), (clippedvec-direction).get(), self.thickness)



    def draw(self, screen, offset, direction):
        ''' method draw is useful for piecewise drawing '''
        self.drawWrappedLine(self.color, screen, offset, direction)


    def drawBoing(self, screen):
        (x,y) = self.getScreenPos(screen).get()
        pygame.draw.circle(screen, self.color, (int(x),int(y)), self.thickness*2);
        pygame.display.update(pygame.rect.Rect(x-self.thickness, y-self.thickness, 2*self.thickness, 2*self.thickness));


    def erase(self, screen, tailToErase):
        inscreenOffset = self.getScreenPos(screen, self.getTail())

        for vec in tailToErase:
            self.drawWrappedLine(self.backgroundcol, screen, inscreenOffset, vec)
            #pygame.draw.line(screen, self.backgroundcol, inscreenOffset.get(), (inscreenOffset+vec).get(), self.thickness)
            inscreenOffset = self.getScreenPos(screen, inscreenOffset+vec)


    ''' collisiondetection
        check corridor in front of snake,
        start at (thickness+1)/2 distance to be not disturbed by turnings
    '''
    def getCollisionCorridor(self, offset, relativevec):
        # collect checkpoints
        direction = relativevec.normalize()
        ortho = relativevec.getOrthogonalVec().normalize()
        minlength = (self.thickness+1)/2
        maxlength = relativevec.getLength()
        pointsToCheck = []

        pos = minlength
        # make sure to test at least minimal checkpoints:
        if maxlength < minlength:
            maxlength = pos
        while maxlength >= pos:
            checkpoint2 = offset + pos*direction
            checkpoint1 = checkpoint2 - ((self.thickness-1)/2)*ortho
            checkpoint3 = checkpoint2 + ((self.thickness-1)/2)*ortho
            pointsToCheck.append(checkpoint1)
            pointsToCheck.append(checkpoint2)
            pointsToCheck.append(checkpoint3)
            pos = pos + self.thickness - 1
        return pointsToCheck


    def getScreenPoints(self, screen, points):
        screenpoints = dict()
        for point in points:
            vecToCheck = self.getScreenPos(screen, point)
            (x,y) = vecToCheck.get()
            screencolor = screen.get_at((int(x), int(y)))
            screenpoints[repr(vecToCheck)]= screencolor
        return screenpoints


    def isFreeWay(self, screen, collisionPoints):
        for color in collisionPoints.values():
            if self.backgroundcol != color and self.food.foodcolor != color:
                return 0
        return 1


    def checkForFood(self, screen, pointsToCheck):
        for color in pointsToCheck.values():
            if self.food.foodcolor == color:
                return 1
        return 0


    def wouldcollide(self, screen, speed, heading=None):
        if None==heading:
            heading = -1 * self.inversedirectionvectors[0].normalize()
        direction = speed*heading
        # trick to not let the ai snake collisiondetection fool itself
        offset = self.getScreenPos(screen, self.abspos + int(self.thickness/2) * heading)
        pointsToCheck = self.getCollisionCorridor(offset, direction)
        pointcols = self.getScreenPoints(screen, pointsToCheck)
        # first check free corridor, then draw
        if self.isFreeWay(screen, pointcols):
            return 0
        return 1


    def getScreenPos(self, screen, vector=None):
        if None==vector:
            vector = self.abspos
        return vector % Vec(screen.get_bounding_rect().width, screen.get_bounding_rect().height)


    def moveahead(self, distance, turn = None):
        heading = Vec(0,0)
        # if current direction gets continued do not make an additional entry
        if (None != turn) and (-1 * self.inversedirectionvectors[0].normalize() != turn):
            heading = distance*turn
            self.inversedirectionvectors.insert(0, -1*heading)
        else:
            inverseheading = distance * self.inversedirectionvectors[0].normalize()
            self.inversedirectionvectors[0] = self.inversedirectionvectors[0] + inverseheading
            heading = -1 * inverseheading
        self.abspos += heading

        # eventually drop last turns
        lastchangeindex = 0
        cummulativelength = 0
        for turnvec in self.inversedirectionvectors:
            cummulativelength += turnvec.getLength()
            if cummulativelength >= self.snakelength:
                break
            else:
                lastchangeindex += 1

        clearList = []
        if lastchangeindex +1 < len(self.inversedirectionvectors):
            clearList = self.inversedirectionvectors[(lastchangeindex+1):]
            del self.inversedirectionvectors[(lastchangeindex+1):]

        # in the starting phase the oversize may be negative
        oversize = (cummulativelength - self.snakelength)
        if oversize > 0:
            # fix last item
            vectortofix = self.inversedirectionvectors[-1]
            newlength = vectortofix.getLength() - oversize
            fixedvec = newlength * vectortofix.normalize()
            self.inversedirectionvectors[-1] = fixedvec
            # append the appropriate vector to the clear list
            restvector = vectortofix - fixedvec
            clearList.insert(0, restvector)
        return clearList


    def getEnclosingRect(self):
        # traverse along the snake and collect min/max values
        x = x_max = x_min = self.abspos.x
        y = y_max = y_min = self.abspos.y

        for relativevec in self.inversedirectionvectors:
            x += relativevec.x
            y += relativevec.y
            if x < x_min:
                x_min = x
            if x > x_max:
                x_max = x
            if y < y_min:
                y_min = y
            if y > y_max:
                y_max = y

        thickness_mod = math.ceil(self.thickness/2.0)
        r = pygame.Rect(x_min-thickness_mod, y_min-thickness_mod,
                        x_max-x_min+2*thickness_mod, y_max-y_min+2*thickness_mod)
        return r



    '''
        @return 0 if it hit an obstacle, 1 if there was no obstacle
    '''
    def cycle(self, screen, speed, heading):
        inscreenOffset = self.getScreenPos(screen) # important: current screenpos
        direction = speed*heading
        pointsToCheck = self.getCollisionCorridor(inscreenOffset, direction)
        pointcols = self.getScreenPoints(screen, pointsToCheck)
        # first check free corridor, then draw
        freeWay = self.isFreeWay(screen, pointcols)
        foundfood = 0
        if self.checkForFood(screen, pointcols):
            self.grow(self.food.suggestedgrowsize)
            self.food.clearfood()
            foundfood = 1
        self.draw(screen, inscreenOffset, direction)
        # create food after drawing the snake
        if foundfood:
            self.food.placeAndRenderFood()
        # let the model update
        tailToErase = self.moveahead(speed, heading);
        self.erase(screen, tailToErase)
        return freeWay


class Snake(ProtoSnake):
    def __init__(self, col, x, y, backgroundcol, head, length, thickness,
                 leftkey, rightkey, upkey, downkey, messagelog, food ):

        ProtoSnake.__init__(self, col, x, y, backgroundcol, head, length, thickness, food)

        self.leftkey  = leftkey
        self.rightkey = rightkey
        self.upkey    = upkey
        self.downkey  = downkey
        self.debug = messagelog


    def cycle(self, screen, speed=1, key=None):
        heading = -1 * self.inversedirectionvectors[0].normalize()
        # the scalarproduct is used to only allow 90 deg-turns
        # it is zero if there is an rectangular angle between
        # the current direction and the direction to test for
        if (self.leftkey == key) and (0 == ProtoSnake.right * self.inversedirectionvectors[0]):
            heading = ProtoSnake.left
        if (self.rightkey == key) and (0 == ProtoSnake.right * self.inversedirectionvectors[0]):
            heading = ProtoSnake.right
        if (self.downkey == key) and (0 == ProtoSnake.up * self.inversedirectionvectors[0]):
            heading = ProtoSnake.down
        if (self.upkey == key) and (0 == ProtoSnake.up * self.inversedirectionvectors[0]):
            heading = ProtoSnake.up

        return ProtoSnake.cycle(self, screen, speed, heading)


class AiSnake(ProtoSnake):
    def __init__(self, col, x, y, backgroundcol, head, length, thickness, changeprob, messagelog, food):
        ProtoSnake.__init__(self, col, x, y, backgroundcol, head, length, thickness, food)
        self.changeprob = changeprob
        self.rng = random
        self.debug = messagelog


    def cycle(self, screen, speed):
        heading = -1 * self.inversedirectionvectors[0].normalize()
        collisiondistance = 2*speed + self.thickness
        if self.wouldcollide(screen, collisiondistance):
           self.debug.log('WARNING: ai collision threat')
        if (self.wouldcollide(screen, collisiondistance) or self.changeprob >= self.rng.randint(1, 100)):
            # build array of possible headings
            headingchanges = [];
            # look which directions are alternativly available,
            # forbidden are the same, the opposite (both checked by scalar product)
            # and collision-directions
            if (0 == ProtoSnake.right * heading) and \
               (0 == self.wouldcollide(screen, collisiondistance, ProtoSnake.left)):
                headingchanges.append(ProtoSnake.left);
            if (0 == ProtoSnake.right * heading) and \
               (0 == self.wouldcollide(screen, collisiondistance, ProtoSnake.right)):
                headingchanges.append(ProtoSnake.right);
            if (0 == ProtoSnake.up * heading) and \
               (0 == self.wouldcollide(screen, collisiondistance, ProtoSnake.up)):
                headingchanges.append(ProtoSnake.up);
            if (0 == ProtoSnake.up * heading) and \
               (0 == self.wouldcollide(screen, collisiondistance, ProtoSnake.down)):
                headingchanges.append(ProtoSnake.down);

            feasiblechanges = len(headingchanges);
            if (feasiblechanges>0):
                # random
                # -1 to adjust index
                directionchange = self.rng.randint(1, feasiblechanges) - 1;
                # set real change of direction
                heading = headingchanges[directionchange];
                self.debug.log('ai changing heading to ' + str(heading))
            else:
                self.debug.log('ai found no alternative')

        return ProtoSnake.cycle(self, screen, speed, heading)


if __name__ == '__main__':
    import time, sys, traceback
    width = 600
    height = 300
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((width, height))
    try:
        snake = ProtoSnake()
        snake.moveahead(20)
        snake.moveahead(3)
        snake.moveahead(3)
        snake.moveahead(3)
        snake.moveahead(3)
        snake.moveahead(3, ProtoSnake.down)
        snake.moveahead(3)
        snake.moveahead(3)
        snake.moveahead(3)
        snake.moveahead(3, ProtoSnake.left)
        snake.moveahead(3)
        snake.moveahead(3)
        snake.moveahead(3)
        snake.fullrender(screen)

        snake1 = ProtoSnake((0,0,255), 120, 60, (255,255,255), ProtoSnake.down, 80, 5)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(3, ProtoSnake.left)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(3, ProtoSnake.down)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(20, ProtoSnake.right)
        snake1.fullrender(screen)

        snake2 = ProtoSnake((255,0,0), 20, 60, (255,255,255), ProtoSnake.down, 80, 3)
        snake2.moveahead(9)
        snake2.moveahead(9, ProtoSnake.left)
        snake2.moveahead(9, ProtoSnake.down)
        snake2.moveahead(20, ProtoSnake.right)
        snake2.fullrender(screen)

        snake3 = ProtoSnake((255,255,0), 220, 60, (255,255,255), ProtoSnake.down, 80, 3)
        snake3.moveahead(40)
        snake3.moveahead(20, ProtoSnake.left)
        snake3.fullrender(screen)

        pygame.display.update()
        time.sleep(4)
    except Exception, e:
        tb = sys.exc_info()[2]
        traceback.print_exception(e.__class__, e, tb)
        raw_input('\nenter to exit\n')
    pygame.quit()