import unittest, sys, traceback, pygame;
from time import sleep;

import snake, tools.vec


class TestSnake(unittest.TestCase):

    def setUp(self):
        self.snake = snake.ProtoSnake((125,125,0), 100, 100, (255,255,255), snake.ProtoSnake.right, 80, 5);
        self.snake.moveahead(30)


    def testGrowing(self):
        size = self.snake.getsize();
        self.snake.grow();
        self.assertEqual(size + 1, self.snake.getsize(), 'snake is not grown!');


    def testSnakemovementRight(self):
        start = self.snake.abspos
        self.snake.moveahead(10, snake.ProtoSnake.right)
        target = self.snake.abspos
        self.assertEqual(start.y, target.y, 'snake has illegally changed y-value')
        self.assertEqual(start.x+10, target.x, 'snake has not moved 10 units to the right')


    def testSnakemovementLeft(self):
        start = self.snake.abspos
        self.snake.moveahead(23, snake.ProtoSnake.left)
        target = self.snake.abspos
        self.assertEqual(start.y, target.y, 'snake has illegally changed y-value')
        self.assertEqual(start.x-23, target.x, 'snake has not moved 23 units to the left')


    def testSnakemovementUp(self):
        start = self.snake.abspos
        self.snake.moveahead(15, snake.ProtoSnake.up)
        target = self.snake.abspos
        self.assertEqual(start.x, target.x, 'snake has illegally changed x-value')
        self.assertEqual(start.y-15, target.y, 'snake has not moved 15 units up')


    def testSnakemovementDown(self):
        start = self.snake.abspos
        self.snake.moveahead(6, snake.ProtoSnake.down)
        target = self.snake.abspos
        self.assertEqual(start.x, target.x, 'snake has illegally changed x-value')
        self.assertEqual(start.y+6, target.y, 'snake has not moved 6 units down')
        start = self.snake.abspos
        self.snake.moveahead(16)
        target = self.snake.abspos
        self.assertEqual(start.x, target.x, 'snake has illegally changed x-value')
        self.assertEqual(start.y+16, target.y, 'snake has not moved 6 units down')


    def testEnclosingRect(self):
        start = self.snake.abspos
        self.snake.moveahead(self.snake.snakelength, snake.ProtoSnake.down)
        self.snake.moveahead(10, snake.ProtoSnake.right)
        enclosingRect = self.snake.getEnclosingRect()
        self.assertEqual(start.x-3, enclosingRect.x, 'enclosingRect has wrong x-offset')
        self.assertEqual(start.y+7, enclosingRect.y, 'enclosingRect has not moved y-offset 10 units')
        self.assertEqual(self.snake.snakelength-10+6, enclosingRect.height, 'enclosing Rect has not the correct height')
        self.assertEqual(16, enclosingRect.width, 'enclosing Rect has not the correct width')


    def testRepr(self):
        anotherSnake = snake.ProtoSnake((0,0,0), 20, 60, (255,255,255), snake.ProtoSnake.down, 23, 3)
        self.assertEqual('<ProtoSnake col=(0, 0, 0) backcol=(255, 255, 255) pos=(20.0, 60.0) l=23 t=3 (-0.0, -1.0);>',
                            repr(anotherSnake))


    def testAdvancedMovement(self):
        anotherSnake = snake.ProtoSnake((0,0,0), 20, 60, (255,255,255), snake.ProtoSnake.down, 23, 3)
        self.assertEqual(60, anotherSnake.abspos.y)
        anotherSnake.moveahead(5, snake.ProtoSnake.down)
        anotherSnake.moveahead(5, snake.ProtoSnake.down)
        self.assertEqual(70, anotherSnake.abspos.y)
        self.assertEqual('<ProtoSnake col=(0, 0, 0) backcol=(255, 255, 255) pos=(20.0, 70.0) l=23 t=3 (-0.0, -11.0);>',
                            repr(anotherSnake))



    def testEqualMovements(self):
        snake1 = snake.ProtoSnake((0,0,0), 20, 60, (255,255,255), snake.ProtoSnake.down, 23, 3)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(3, snake.ProtoSnake.left)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(3, snake.ProtoSnake.down)
        snake1.moveahead(3)
        snake1.moveahead(3)
        snake1.moveahead(20, snake.ProtoSnake.right)

        snake2 = snake.ProtoSnake((0,0,0), 20, 60, (255,255,255), snake.ProtoSnake.down, 23, 3)
        snake2.moveahead(9)
        snake2.moveahead(9, snake.ProtoSnake.left)
        snake2.moveahead(9, snake.ProtoSnake.down)
        snake2.moveahead(20, snake.ProtoSnake.right)

        self.assertEqual(repr(snake1), repr(snake2))


    def testReset(self):
        anotherSnake = snake.ProtoSnake((0,0,0), 20, 60, (255,255,255), snake.ProtoSnake.down, 23, 3)
        anotherSnake.moveahead(30)
        anotherSnake.moveahead(10, snake.ProtoSnake.left)
        anotherSnake.reset(snake.ProtoSnake.right)
        self.assertEqual(1, len(anotherSnake.inversedirectionvectors))
        self.assertEqual('(-1.0, -0.0)', repr(anotherSnake.inversedirectionvectors[0]))


    def testGetTail(self):
        asnake = snake.ProtoSnake((0,0,0), 20, 60, (255,255,255), snake.ProtoSnake.down, 23, 3)
        self.assertEqual(tools.vec.Vec(20,59), asnake.getTail())
        asnake.moveahead(10, snake.ProtoSnake.right)
        self.assertEqual(tools.vec.Vec(20,59), asnake.getTail())
        asnake.moveahead(15, snake.ProtoSnake.down)
        self.assertEqual(tools.vec.Vec(22,60), asnake.getTail())


if __name__ == '__main__':
    #unittest.main();
    suite = unittest.TestLoader().loadTestsFromTestCase(TestSnake)
    unittest.TextTestRunner(verbosity=2).run(suite)
    raw_input('enter\n');
