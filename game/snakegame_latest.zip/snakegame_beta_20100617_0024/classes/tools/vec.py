import math, types


class Vec():


    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)


    def __repr__(self):
        return '(' + str(self.x) + ', ' + str(self.y) + ')'


    def get(self):
        return (self.x, self.y)


    def getLength(self):
        if (0==self.x) or (0==self.y): # quicker operation
            return math.fabs(self.x + self.y)
        else:
            return math.sqrt(self.x*self.x + self.y*self.y)

    def normalize(self):
        length = self.getLength()
        if 0==length:
            raise ValueError()
        if 1==length:
            return Vec(self.x, self.y)
        return (1.0/length) * self


    ''' operator overloading '''
    ''' multiplication '''
    def __mul__(self, other):
        if isinstance(other, Vec):
            c = self.x * other.x + self.y * other.y
            return c
        else:
            (newx, newy) = self.x * other, self.y * other
            return Vec(newx, newy)

    def __rmul__(self, other):
        if isinstance(other, Vec):
            raise TypeError()
        (newx, newy) = self.x * other, self.y * other
        return Vec(newx, newy)


    ''' addition '''
    def __add__(self, other):
        if not isinstance(other, Vec):
            raise TypeError()
        (sum_x, sum_y) = self.x + other.x, self.y + other.y
        return Vec(sum_x, sum_y)

    ''' subtraction '''
    def __sub__(self, other):
        if not isinstance(other, Vec):
            raise TypeError()
        (sub_x, sub_y) = self.x - other.x, self.y - other.y
        return Vec(sub_x, sub_y)

    def __rsub__(self, other):
        if not isinstance(other, Vec):
            raise TypeError()
        (sub_x, sub_y) = other.x - self.x, other.y - self.y
        return Vec(sub_x, sub_y)

    ''' modulo '''
    def __mod__(self, other):
        if isinstance(other, Vec):
            return Vec(self.x % other.x, self.y % other.y)
        else:
            return Vec(self.x % other, self.y % other)

    ''' comparision '''
    def __eq__(self, other):
        if isinstance(other, types.NoneType):
            return False
        if not isinstance(other, Vec):
            raise TypeError()
        if (self.x == other.x) and (self.y == other.y):
            return True
        else:
            return False

    def __ne__(self, other):
        if isinstance(other, types.NoneType):
            return True
        if not isinstance(other, Vec):
            raise TypeError()
        return not (self == other)


    ''' this method calculates one orthogonal vector, out of n
        the calculation is based on the fact that
        <a,b> == 0 holds for every orthogonal pair of vectors
        (<,> as scalar product, sometimes referred to as dot product or
        direct product) '''
    def getOrthogonalVec(self):
        if self.x != 0:
            return Vec(-self.y/self.x, 1)
        if self.y != 0:
            return Vec(1, -self.x/self.y)
        raise ValueError()