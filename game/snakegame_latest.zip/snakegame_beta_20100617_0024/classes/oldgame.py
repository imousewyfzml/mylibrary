import pygame, time, cmath, random, os

from snake import Snake, AiSnake, ProtoSnake
from gamegrid import Gamegrid
import tools.debuggingtools
import tools.vec
import tools.mediahelper
import foodmanager
import infoscreen

class Game:
    unitsize = 40
    growsize = 200
    thickness = 5
    initallength = 40
    background = (170,238,187,255)
    foodcolor = (255,172,255,255)
    width = 840
    height = 400
    infoheight = 20
    maxleveltime = 120


    def __init__(self, screen):
        enabledebugging = 0
        self.info = infoscreen.Infoscreen(Game.width, Game.infoheight)
        self.infochange = 1
        self.gamelog = tools.debuggingtools.Messagelog(enabledebugging, 'Game: ')
        self.maxfps = 30
        self.speed = 4
        self.clock = pygame.time.Clock();
        self.snakecolor = (255, 100, 0);
        self.food = foodmanager.Foodmanager(Game.width, Game.height, 2*Game.thickness,
            Game.background, Game.foodcolor, Game.growsize)
        self.mysnake = Snake(self.snakecolor, 10, 50, Game.background,
                             ProtoSnake.right, Game.initallength, Game.thickness,
                             pygame.K_LEFT, pygame.K_RIGHT,
                             pygame.K_UP, pygame.K_DOWN,
                             tools.debuggingtools.Messagelog(enabledebugging, 'Player: '),
                             self.food);
        self.aicolor = (100, 100, 100);
        self.ai = AiSnake(self.aicolor, 30, 50,
                             Game.background,
                             ProtoSnake.left, Game.initallength, Game.thickness,
                             1, # prob of changing direction in percent
                             tools.debuggingtools.Messagelog(enabledebugging, 'AI: '),
                             self.food);
        self.mainscreen = screen
        self.myscreen = pygame.Surface((Game.width, Game.height))
        self.gamerect = pygame.rect.Rect(0, Game.infoheight, Game.width, Game.height)
        self.gamegrid_ = Gamegrid( 21, 10, '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     ');

        self.gamegrid = Gamegrid( 21, 10, 'xxx xxx xxxx xxxxx xx'
                                        + 'x        xxx x      x'
                                        + 'x        xx  xx    xx'
                                        + 'x  xxxxx x    x xxxxx'
                                        + '              x  x   '
                                        + 'x    xx  x xxxx  x  x'
                                        + 'x        x   x     xx'
                                        + 'x        x x    x   x'
                                        + '         x x x  x    '
                                        + 'xxx xxx xxxx xxxxx xx');
        self.tryagainsmiley = tools.mediahelper.loadImage('happyface.png')
        self.initGame();



    def initGame(self):
        self.mysnake.reset(ProtoSnake.right)
        self.ai.reset(ProtoSnake.left)
        self.myscreen.fill(Game.background);
        self.gamegrid.fullrender(self.myscreen, 0, 0, Game.unitsize);
        self.placeSnake(self.mysnake)
        self.placeSnake(self.ai)
        self.food.placeFood(self.myscreen)
        self.food.renderFood(self.myscreen)

        pygame.display.update();

        self.timecount = 0; # give game a timereference
        self.leveltime = 120
        self.info.time = self.leveltime
        self.lastcaptionupdate = 0
        self.gamerunning = 1;

        pygame.display.set_caption(".. .: game running :. ..");


    def placeSnake(self, snake):
        snakeinwall = 1;
        max_iterations = 100
        iteration = 0
        while iteration < max_iterations and snakeinwall:
            iteration += 1
            # generate new random position
            snake.abspos = tools.vec.Vec(random.randint(
                            1,self.myscreen.get_bounding_rect().width) - 1 \
                            , random.randint(
                            1,self.myscreen.get_bounding_rect().height) -1);
            (x,y) = snake.abspos.get()
            screencolor = self.myscreen.get_at((int(x), int(y)))
            if ( Game.background != screencolor ):
                snakeinwall = 1;
            else:
                # do additional check to not start infront of obstacle
                snakeinwall = snake.wouldcollide(self.myscreen, 20* self.speed);
        # if max_iterations are reached without success -> fail
        if snakeinwall:
            raise ValueError()


    def updateScreen(self):
        if self.infochange:
            self.info.render(self.mainscreen)
            self.infochange = 0
        self.mainscreen.blit(self.myscreen, self.gamerect)
        pygame.display.update()


    def mainloop(self):
        paused = 0
        while 1:
            key = None;
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return;
                if (event.type == pygame.KEYDOWN):
                    if event.key == pygame.K_q:
                        return;
                    if (0 == self.gamerunning and pygame.K_n == event.key):
                        self.initGame();
                    elif (pygame.K_p == event.key):
                        paused = not paused
                        if self.gamerunning and paused:
                            pygame.display.set_caption(".. .: game paused :. .. ");
                    else:
                        key = event.key;

            passedmillis=0
            if (self.gamerunning and not paused):
                selfboing = 0;
                aiboing = 0;

                if (0 == self.mysnake.cycle(self.myscreen, self.speed, key)):
                    self.mysnake.drawBoing(self.myscreen)
                    selfboing = 1;
                if (0 == self.ai.cycle(self.myscreen, self.speed)):
                    self.ai.drawBoing(self.myscreen)
                    aiboing = 1;

                if (selfboing and aiboing):
                    pygame.display.set_caption("draw game");
                    self.gamelog.log("draw game")
                elif selfboing:
                    pygame.display.set_caption("BOING!");
                    self.gamelog.log("BOING!")
                    tools.mediahelper.showText(self.myscreen, 'Boing! Try Again!', 30, None, Game.height/2 - 100, (0,0,0), (255,255,255))
                    tools.mediahelper.showImage(self.myscreen, self.tryagainsmiley, 20, 10)
                elif aiboing:
                    pygame.display.set_caption("you win!");
                    self.gamelog.log("you win!")
                if (selfboing or aiboing):
                    self.gamerunning = 0;
                    tools.mediahelper.showText(self.myscreen, "new game: press n / quit: press q");

                # update time
                oldleveltime = self.leveltime
                self.leveltime = Game.maxleveltime - (self.timecount / 1000)
                if self.leveltime < 0:
                    self.leveltime = 0
                if oldleveltime > self.leveltime:
                    self.info.time = self.leveltime
                    self.infochange = 1
                self.updateScreen()

            passedmillis = self.clock.tick(self.maxfps); # argument is the max framerate
            self.timecount += passedmillis

            # only set the fps caption in a distinct intervall
            if self.gamerunning and self.lastcaptionupdate + 1000 < self.timecount:
                self.lastcaptionupdate = self.timecount
                fps = int(1000.0/passedmillis)
                pygame.display.set_caption(".. .: game running :. .. " + str(fps) + ' fps');
