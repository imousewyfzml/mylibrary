import vec
import unittest, pdb


class vecTest(unittest.TestCase):


    def testUnitLength(self):
        unit1 = vec.Vec(1,0)
        self.assertEqual(1, unit1.getLength(), 'Unitvector should have a length of one unit ')
        unit2 = vec.Vec(0,1)
        self.assertEqual(1, unit2.getLength(), 'Unitvector should have a length of one unit ')
        minusUnit1 = vec.Vec(-1,0)
        self.assertEqual(1, minusUnit1.getLength(), 'Unitvector should have a length of one unit ')
        minusUnit2 = vec.Vec(0,-1)
        self.assertEqual(1, minusUnit2.getLength(), 'Unitvector should have a length of one unit ')


    def testGenericLength(self):
        largePositive = vec.Vec(3, 4)
        self.assertEqual(5, largePositive.getLength(), 'largePositive should have a length of 5 units')


    def testStandardMultiplication(self):
        a = vec.Vec(1,0)
        minusA = a * -1
        self.assertEqual(-1, minusA.x, 'x-component should be -1')
        self.assertEqual(0, minusA.y, 'y-component should be 0')

        a = vec.Vec(23, 2.1)
        newA = a * 2
        self.assertAlmostEqual(46, newA.x, 5, 'x-component should be 46')
        self.assertAlmostEqual(4.2, newA.y, 5, 'y-component should be 4.2')

        newA = a * 1.5
        self.assertAlmostEqual(34.5, newA.x, 5, 'x-component should be 34.5')
        self.assertAlmostEqual(3.15, newA.y, 5, 'y-component should be 3.15')



    def testRightMultiplication(self):
        a = vec.Vec(1,0)
        minusA = -1 * a
        self.assertEqual(-1, minusA.x, 'x-component should be -1')
        self.assertEqual(0, minusA.y, 'y-component should be 0')

        a = vec.Vec(23, 2.1)
        newA = 2 * a
        self.assertAlmostEqual(46, newA.x, 5, 'x-component should be 46')
        self.assertAlmostEqual(4.2, newA.y, 5, 'y-component should be 4.2')

        newA = 1.5 * a
        self.assertAlmostEqual(34.5, newA.x, 5, 'x-component should be 34.5')
        self.assertAlmostEqual(3.15, newA.y, 5, 'y-component should be 3.15')


    def testInplaceMultiplication(self):
        a = vec.Vec(1,0)
        a *= -1
        self.assertEqual(-1, a.x, 'x-component should be -1')
        self.assertEqual(0, a.y, 'y-component should be 0')

        b = vec.Vec(-25,10)
        b *= -0.2
        self.assertAlmostEqual(5, b.x, 5, 'x-component should be 5')
        self.assertAlmostEqual(-2, b.y, 5, 'y-component should be -2')


    def testScalarMultiplication(self):
        a = vec.Vec(1,1)
        b = vec.Vec(2,3)
        c = a * b
        self.assertEqual(5, c)


    def testDefaultAddition(self):
        a = vec.Vec(2,3)
        b = vec.Vec(5,6)
        c = a + b
        self.assertEqual(7, c.x, 'x-comp should be 7')
        self.assertEqual(9, c.y, 'y-comp should be 9')


    def testInplaceAddition(self):
        a = vec.Vec(2,-3)
        b = vec.Vec(-5,-6)
        a += b
        self.assertEqual(-3, a.x, 'x-comp should be -3')
        self.assertEqual(-9, a.y, 'y-comp should be -9')


    def testUnsupportedAddition(self):
        a = vec.Vec(1,0)
        b = 3
        try:
            c = a + b
            self.fail('addition of vector and scalar should not be allowed')
        except TypeError as e:
            pass;


    def testDefaultSubtraction(self):
        a = vec.Vec(2,3)
        b = vec.Vec(5,6)
        c = a - b
        self.assertEqual(-3, c.x, 'x-comp should be -3')
        self.assertEqual(-3, c.y, 'y-comp should be -3')


    def testRightSubtraction(self):
        a = vec.Vec(2,3)
        b = vec.Vec(5,6)
        c = b - a
        self.assertEqual(3, c.x, 'x-comp should be 3')
        self.assertEqual(3, c.y, 'y-comp should be 3')


    def testInplaceSubtraction(self):
        a = vec.Vec(1,4)
        b = vec.Vec(5,6)
        a -= b
        self.assertEqual(-4, a.x, 'x-comp should be -3')
        self.assertEqual(-2, a.y, 'y-comp should be -3')


    def testUnsupportedSubtraction1(self):
        a = vec.Vec(1,0)
        b = 3
        try:
            c = a - b
            self.fail('subtraction of scalar from vector should not be allowed')
        except TypeError as e:
            pass;


    def testUnsupportedSubtraction2(self):
        a = vec.Vec(1,0)
        b = 3
        try:
            c = b - a
            self.fail('subtraction of scalar from vector should not be allowed')
        except TypeError as e:
            pass;

    def testScalarModulo(self):
        a = vec.Vec(54, 31)
        c = a % 5
        self.assertEqual(4, c.x)
        self.assertEqual(1, c.y)

    def testVectorModulo(self):
        a = vec.Vec(55, 31)
        b = vec.Vec(6, 7)
        c = a % b
        self.assertEqual(1, c.x)
        self.assertEqual(3, c.y)

    def testNormalization(self):
        bigvec = vec.Vec(-32, 456.2)
        normalizedbigvec = bigvec.normalize()
        self.assertEqual(1, normalizedbigvec.getLength(), 'After normalization vectorlength has to be 1')

        uno = vec.Vec(-234, 0)
        normalizedUno = uno.normalize()
        self.assertEqual(-1, normalizedUno.x, 'x should be -1')
        self.assertEqual(0, normalizedUno.y, 'y should be 0')

        duo = vec.Vec(0, 250)
        normalizedDuo = duo.normalize()
        self.assertEqual(0, normalizedDuo.x, 'x should be 0')
        self.assertEqual(1, normalizedDuo.y, 'y should be 1')


    def testRepr(self):
        myvec = vec.Vec(23, 56)
        self.assertEqual('(23.0, 56.0)', repr(myvec))


    def testEq(self):
        a = vec.Vec(34.0, 0)
        b = vec.Vec(1.0, 0)
        c = a.normalize()
        self.assertTrue(b==c)
        self.assertFalse(a==b)
        self.assertFalse(None==a)


    def testNe(self):
        a = vec.Vec(34.0, 0)
        b = vec.Vec(1.0, 0)
        c = a.normalize()
        self.assertTrue(a!=b)
        self.assertFalse( b!=c)
        self.assertNotEqual(a,b)
        self.assertNotEqual(None, a)


    def testGetOrthoVec(self):
        a = vec.Vec(23,0)
        b = a.getOrthogonalVec()
        self.assertFalse(b==vec.Vec(0,0))
        self.assertEqual(0, a*b)
        try:
            nullvec = vec.Vec(0,0)
            c = nullvec.getOrthogonalVec()
            self.fail('nullvector should not have an orthogonal vector')
        except ValueError as e:
            pass;

if __name__ == '__main__':
    #unittest.main();
    suite = unittest.TestLoader().loadTestsFromTestCase(vecTest)
    unittest.TextTestRunner(verbosity=2).run(suite)