import pygame, time, cmath, random, os

from snake import Snake, AiSnake, ProtoSnake
from gamegrid import Gamegrid
import tools.debuggingtools
import tools.vec
import tools.mediahelper
import foodmanager
import infoscreen

class Level:
    enabledebugging = 0
    unitsize = 40
    thickness = 5
    growsize = 20
    background = (170,238,187,255)
    foodcolor = (0,0,255,255)

    def __init__(self, screen, snakecolor, speed):
        self.screen = screen
        self.snakecolor = snakecolor;
        self.speed = speed

    def getLevelInfo(self): abstract
        #return '''provide good help string for how to win the level'''


    def getScore(self):
        return 100


    def placeSnake(self, snake):
        snakeinwall = 1;
        max_iterations = 100
        iteration = 0
        (width, height) = self.screen.get_size()
        while iteration < max_iterations and snakeinwall:
            iteration += 1
            # generate new random position
            snake.abspos = tools.vec.Vec(random.randint(
                            1, width) - 1 \
                            , random.randint(
                            1, height) -1);
            (x,y) = snake.abspos.get()
            screencolor = self.screen.get_at((int(x), int(y)))
            if ( Level.background != screencolor ):
                snakeinwall = 1;
            else:
                # do additional check to not start infront of obstacle
                snakeinwall = snake.wouldcollide(self.screen, 20* self.speed);
        # if max_iterations are reached without success -> fail
        if snakeinwall:
            raise ValueError()


class SimpleLevel(Level):

    def __init__(self, screen, snakecolor, speed):
        Level.__init__(self, screen, snakecolor, speed)

        self.food = foodmanager.Foodmanager(screen, 2*Level.thickness,
                        Level.background, Level.foodcolor, Level.growsize)
        self.mysnake = Snake(self.snakecolor, 10, 50, Level.background,
                             ProtoSnake.right, Level.growsize, Level.thickness,
                             pygame.K_LEFT, pygame.K_RIGHT,
                             pygame.K_UP, pygame.K_DOWN,
                             tools.debuggingtools.Messagelog(Level.enabledebugging, 'Player: '),
                             self.food);

        self.gamegrid = Gamegrid( 21, 10, '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     '
                                         + '                     ');



    def initGame(self):
        self.mysnake.reset(ProtoSnake.right)
        self.screen.fill(Level.background);
        self.gamegrid.fullrender(self.screen, 0, 0, Level.unitsize);
        self.placeSnake(self.mysnake)
        self.food.placeAndRenderFood()



    def cycle(self, key):
        status = 'running'
        if (0 == self.mysnake.cycle(self.screen, self.speed, key)):
            self.mysnake.drawBoing(self.screen)
            status = 'loose'
        if (100 <= self.mysnake.snakelength):
            status = 'win'
        return status


    def getLevelInfo(self):
        return 'grow baby, grow ..'


class SimpleLevel2(Level):

    def __init__(self, screen, snakecolor, speed):
        Level.__init__(self, screen, snakecolor, speed)

        self.food = foodmanager.Foodmanager(screen, 2*Level.thickness,
                        Level.background, Level.foodcolor, Level.growsize)
        self.mysnake = Snake(self.snakecolor, 10, 50, Level.background,
                             ProtoSnake.right, 100, Level.thickness,
                             pygame.K_LEFT, pygame.K_RIGHT,
                             pygame.K_UP, pygame.K_DOWN,
                             tools.debuggingtools.Messagelog(Level.enabledebugging, 'Player: '),
                             self.food);

        self.gamegrid = Gamegrid( 21, 10, '                     '
                                         + '                x    '
                                         + '     xx         x    '
                                         + '     xx              '
                                         + '           xx        '
                                         + '          xxxx       '
                                         + '           xx        '
                                         + '                     '
                                         + '        x            '
                                         + '                     ');



    def initGame(self):
        self.mysnake.reset(ProtoSnake.right)
        self.screen.fill(Level.background);
        self.gamegrid.fullrender(self.screen, 0, 0, Level.unitsize);
        self.placeSnake(self.mysnake)
        self.food.placeAndRenderFood()



    def cycle(self, key):
        status = 'running'
        if (0 == self.mysnake.cycle(self.screen, self.speed, key)):
            self.mysnake.drawBoing(self.screen)
            status = 'loose'
        if (200 <= self.mysnake.snakelength):
            status = 'win'
        return status


    def getLevelInfo(self):
        return 'grow to your double size, however be aware of the obstacles ..'





class SimpleLevel3(Level):

    def __init__(self, screen, snakecolor, speed):
        Level.__init__(self, screen, snakecolor, speed)

        self.food = foodmanager.Foodmanager(screen, 2*Level.thickness,
                        Level.background, Level.foodcolor, Level.growsize)
        self.mysnake = Snake(self.snakecolor, 10, 50, Level.background,
                             ProtoSnake.right, 200, Level.thickness,
                             pygame.K_LEFT, pygame.K_RIGHT,
                             pygame.K_UP, pygame.K_DOWN,
                             tools.debuggingtools.Messagelog(Level.enabledebugging, 'Player: '),
                             self.food);

        self.gamegrid = Gamegrid( 21, 10,  'xx xxxxxxxxxxxx xxxxx'
                                         + 'xx xxxxxxxxxxxx xxxxx'
                                         + 'xx xxxxxxxxxxxx xxxxx'
                                         + 'xx xxxxxxxxxxxx xxxxx'
                                         + 'xx xxxxxxxxxxxx xxxxx'
                                         + 'xx xxxxxxxxxxxx xxxxx'
                                         + '                     '
                                         + 'xx xxxxxxxxxxxx xxxxx'
                                         + 'xx xxxxxxxxxxxx xxxxx'
                                         + 'xx xxxxxxxxxxxx xxxxx');



    def initGame(self):
        self.mysnake.reset(ProtoSnake.right)
        self.screen.fill(Level.background);
        self.gamegrid.fullrender(self.screen, 0, 0, Level.unitsize);
        self.placeSnake(self.mysnake)
        self.food.placeAndRenderFood()



    def cycle(self, key):
        status = 'running'
        if (0 == self.mysnake.cycle(self.screen, self.speed, key)):
            self.mysnake.drawBoing(self.screen)
            status = 'loose'
        if (300 <= self.mysnake.snakelength):
            status = 'win'
        return status


    def getLevelInfo(self):
        return 'Eat again, dont touch the walls, do you smell the fear of your enemy ?'



class DifficultAILabyLevel(Level):

    def __init__(self, screen, snakecolor, speed):
        Level.__init__(self, screen, snakecolor, speed)

        self.food = foodmanager.Foodmanager(screen, 2*Level.thickness,
                        Level.background, Level.foodcolor, Level.growsize)
        self.mysnake = Snake(self.snakecolor, 10, 50, Level.background,
                             ProtoSnake.right, 300, Level.thickness,
                             pygame.K_LEFT, pygame.K_RIGHT,
                             pygame.K_UP, pygame.K_DOWN,
                             tools.debuggingtools.Messagelog(Level.enabledebugging, 'Player: '),
                             self.food);
        self.aicolor = (100, 100, 100);
        self.ai = AiSnake(self.aicolor, 30, 50,
                             Level.background,
                             ProtoSnake.left, 100, Level.thickness,
                             1, # prob of changing direction in percent
                             tools.debuggingtools.Messagelog(Level.enabledebugging, 'AI: '),
                             self.food);


        self.gamegrid = Gamegrid( 21, 10, 'xxx xxx xxxx xxxxx xx'
                                        + 'x        xxx x      x'
                                        + 'x        xx  xx    xx'
                                        + 'x  xxxxx x    x xxxxx'
                                        + '              x  x   '
                                        + 'x    xx  x xxxx  x  x'
                                        + 'x        x   x     xx'
                                        + 'x        x x    x   x'
                                        + '         x x x  x    '
                                        + 'xxx xxx xxxx xxxxx xx');



    def getScore(self):
        return 200


    def getLevelInfo(self):
        return 'Defeat the other snake, before it gets you!'


    def initGame(self):
        self.mysnake.reset(ProtoSnake.right)
        self.ai.reset(ProtoSnake.left)
        self.screen.fill(Level.background);
        self.gamegrid.fullrender(self.screen, 0, 0, Level.unitsize);
        self.placeSnake(self.mysnake)
        self.placeSnake(self.ai)
        self.food.placeAndRenderFood()

        pygame.display.update();


    def cycle(self, key):
        status = 'running'
        if (0 == self.mysnake.cycle(self.screen, self.speed, key)):
            self.mysnake.drawBoing(self.screen)
            status = 'loose'
        # no draw allowed
        if ('loose' != status) and(0 == self.ai.cycle(self.screen, self.speed)):
            self.ai.drawBoing(self.screen)
            status = 'win'
        return status